#!/bin/bash

md_file="$1"
python3 -m eosfactory.save_code "${md_file}"