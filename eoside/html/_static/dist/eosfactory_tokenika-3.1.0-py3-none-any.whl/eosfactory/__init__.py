'''Library for development and tests of the EOSIO smart contracts.

.. moduleauthor:: Tokenika
'''
import eosfactory.core.config

name = "eosfactory"

__version__ = eosfactory.core.config.VERSION