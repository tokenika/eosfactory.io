#include <eosio/eosio.hpp>
#include <eosio/tester.hpp>
#include <foo.hpp>


using namespace eosio;
using namespace eosio::native;


EOSIO_DISPATCH(foo, (print))

EOSIO_TEST_BEGIN(test)

   printf("\n\n");

   ///////////////////////////////////////////////////////////////////
   // test 1
   ///////////////////////////////////////////////////////////////////
   print_f("Testing CHECK_PRINT(\"Name : xxxxxx\\n\"):\n");

   intrinsics::set_intrinsic<intrinsics::read_action_data>(
         [](void* m, uint32_t len) {
            check(
                     len <= sizeof(eosio::name), 
                     "failed from read_action_data"
               );

            *((eosio::name*)m) = name("xxxxxx");
            
            return len; 
         });

   intrinsics::set_intrinsic<intrinsics::action_data_size>(
         []() {
            return (uint32_t)sizeof(eosio::name);
         });
   
   intrinsics::set_intrinsic<intrinsics::require_auth>(
         [](capi_name nm) {
         });
   
   CHECK_PRINT(
         "Name : xxxxxx\n",
         []() {
            uint64_t receiver = name("any.name").value;
            uint64_t code = name("any.name").value;
            uint64_t action = name("print").value;
            apply(receiver, code, action);
         });

   print_f(
            "Test CHECK_PRINT(\"Name : xxxxxx\\n\") %.\n\n", 
            has_failed() ? "failed" : "passed");

   ///////////////////////////////////////////////////////////////////
   // test 2
   ///////////////////////////////////////////////////////////////////
   print_f("Testing CHECK_PRINT(\"Name : yyyyyy\\n\"):\n");
   intrinsics::set_intrinsic<intrinsics::read_action_data>(
         [](void* m, uint32_t len) {
            check(
                     len <= sizeof(eosio::name), 
                     "failed from read_action_data"
               );
            *((eosio::name*)m) = name("xxxxxx");
            return len; 
         });
   CHECK_PRINT(
         "Name : yyyyyy\n", 
         []() {       
            apply(
               name("any.name").value, 
               name("any.name").value, 
               name("print").value);
         });
   print_f(
            "Test CHECK_PRINT(\"Name : yyyyyy\\n\") %.\n\n", 
            has_failed() ? "failed" : "passed");

   ///////////////////////////////////////////////////////////////////
   // test 3
   ///////////////////////////////////////////////////////////////////
   print_f("Testing CHECK_PRINT(\"Name : YYYYYY\\n\"):\n");
   intrinsics::set_intrinsic<intrinsics::read_action_data>(
         [](void* m, uint32_t len) {
            check(
                  len <= sizeof(eosio::name), 
                  "failed from read_action_data"
            );
            *((eosio::name*)m) = name("YYYYYY");
            return len; 
           });
   CHECK_PRINT(
         "Name : YYYYYY\n", 
         []() {
            apply(
               name("any.name").value, 
               name("any.name").value, 
               name("print").value);
         });
   print_f(
            "Test CHECK_PRINT(\"Name : YYYYYY\\n\") %.\n\n", 
            has_failed() ? "failed" : "passed");

EOSIO_TEST_END


int main(int argc, char** argv) {
   silence_output(false);
   EOSIO_TEST(test);
   return has_failed();
}
 