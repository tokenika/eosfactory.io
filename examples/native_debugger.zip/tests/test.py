import os
import unittest, sys
from eosfactory.eosf import *

verbosity([Verbosity.INFO, Verbosity.OUT])

CONTRACT_WORKSPACE = os.path.join(sys.path[0], "..")

# Actors of the test:
MASTER = MasterAccount()
HOST = Account()

class Test(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        SCENARIO('''
Contract 'foo' has the action 'print', taking an 'eosio:name name' argument, 
that prints, to the console, the message 'Name : <name>\n` (here, '<name>'
represents the actual value of the argument).

Test scenario:
    1. Call the action having 'name = eosio::name("xxxxxx")'. Check whether the 
      console gets the same string.
    2. Call the action having 'name = eosio::name("yyyyyy")'. Check whether the 
      console gets the same string.
    3. Call the action having 'name = eosio::name("YYYYYYY")'. Check whether the 
      node returns error.
        ''')
        
        reset()
        create_master_account("MASTER")
        create_account("HOST", MASTER)

        COMMENT('''
        Build and deploy the contract:
        ''')
        smart = Contract(HOST, CONTRACT_WORKSPACE)
        smart.build(force=False)
        smart.deploy()


    def test1(self):
        COMMENT('''
        Test "Name : xxxxxx\n"
        ''')
        HOST.push_action("print", {"name":"xxxxxx"})
        self.assertTrue(HOST.action.console == "Name : xxxxxx\n")

    def test3(self):
        COMMENT('''
        Test "Name : yyyyyy\n"
        ''')
        HOST.push_action("print", {"name":"yyyyyy"})
        self.assertTrue(HOST.action.console == "Name : yyyyyy\n")

    def test2(self):
        COMMENT('''
        Test "Name : YYYYYY\n"
        Error expected.
        ''')
        with self.assertRaises(Exception):
            HOST.push_action("print", {"name":"YYYYYY"})


    @classmethod
    def tearDownClass(cls):
        stop()


if __name__ == "__main__":
    unittest.main()
