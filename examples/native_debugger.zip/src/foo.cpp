#include <foo.hpp>

void foo::print(name name) {
   print_f("Name : %\n", name);
}
