#include <hello.hpp>

void hello::hi( name nm ) {
   print_f("Name : %\n", nm);
}

void hello::check( name nm ) {
   print_f("Name : %\n", nm);
   eosio::check(nm == name("hello"), "check name not equal to `hello`");
}