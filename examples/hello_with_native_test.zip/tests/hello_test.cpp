#include <eosio/eosio.hpp>
#include <eosio/tester.hpp>

#include <hello.hpp>

using namespace eosio;
using namespace eosio::native;


EOSIO_DISPATCH(hello, (hi)(check))

EOSIO_TEST_BEGIN(hello_test)

   intrinsics::set_intrinsic<intrinsics::read_action_data>(
         [](void* m, uint32_t len) {
            check(len <= sizeof(eosio::name), "failed from read_action_data");
            *((eosio::name*)m) = name("hello");
            return len; 
         });

   intrinsics::set_intrinsic<intrinsics::action_data_size>(
         []() {
            return (uint32_t)sizeof(eosio::name);
         });
   

   intrinsics::set_intrinsic<intrinsics::require_auth>(
         [](capi_name nm) {
         });
/*
CHECK_PRINT(...) macro will check whether the print buffer holds the string 
that is expected and flag the tests as failed but allow the rest of the test 
to run.

This is called either 
CHECK_PRINT("<print message>", [](<args>){ whatever_function(<args>); })
or
CHECK_PRINT(
   [](std::string print_buffer){ user defined comparison function }, 
   [](<args>){ whatever_function(<args>); }
   )
*/
   // "Name : hello" should be in the print buffer
   CHECK_PRINT(
         "Name : hello",
         []() {
/*
The apply(...) function executes the action "hi" of the contract "hello". The
action result with the string "Name : hello" sent to the std_out. The test is passed as the action string equals to the assumed one.
*/            
            apply(name("test").value, name("test").value, name("hi").value);
         });


   // should not assert
   apply(name("test").value, name("test").value, name("check").value);
   
   name nm = name("null");
   intrinsics::set_intrinsic<intrinsics::read_action_data>(
         [&](void* m, uint32_t len) {
            check(len <= sizeof(eosio::name), "failed from read_action_data");
            *((eosio::name*)m) = nm;
            return len; 
         });

   REQUIRE_ASSERT( "check name not equal to `hello`",
         []() {
            // should assert
            apply(name("test").value, name("test").value, name("check").value);
            });

EOSIO_TEST_END


int main(int argc, char** argv) {
   silence_output(false);
   EOSIO_TEST(hello_test);
   return has_failed();
}