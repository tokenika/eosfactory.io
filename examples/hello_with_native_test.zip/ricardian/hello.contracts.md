<h1 class="contract"> hi </h1>

Stub for hi action's ricardian contractrameters
Input parameters:

* `user` (string to include in the output)

Implied parameters: 

* `account_name` (name of the party invoking and signing the contract)

### Intent
INTENT. The intention of the author and the invoker of this contract is to print output. It shall have no other effect.

### Term
TERM. This Contract expires at the conclusion of code execution.