# Testing compilation

## Compilation of the native test specified in `tests/hello_test.cpp`

```
↳ Compiler Options 

▼  ▲  X  ↳ -fnative 
▼  ▲  X  ↳ -o hello 
```

```
./build/hello
error : wrong print message9 {hello_test.cpp:hello_test:39}
hello_test unit test passed
```

## Compilation of a multi-file source

With Compiler Options selecting two source files...
```
↳ Compiler Options 

▼  ▲  X  ↳ --src src/hello.cpp tests/hello_test.cpp 
```

... and with all includes solved...

```
↳ Include

▼  ▲  X  ↳ ${root)/usr/opt/eosio.cdt/1.6.1/include 
▼  ▲  X  ↳ ${root)/usr/opt/eosio.cdt/1.6.1/include/libcxx 
▼  ▲  X  ↳ ${root)/usr/opt/eosio.cdt/1.6.1/include/eosiolib/core 
▼  ▲  X  ↳ ${root)/usr/opt/eosio.cdt/1.6.1/include/eosiolib/capi 
▼  ▲  X  ↳ ${root)/usr/opt/eosio.cdt/1.6.1/include/eosiolib/contracts 
▼  ▲  X  ↳ ${root)/usr/opt/eosio.cdt/1.6.1/include/eosiolib/native 
▼  ▲  X  ↳ ${root)/usr/opt/eosio.cdt/1.6.1/include/eosiolib/native/eosio 
▼  ▲  X  ↳ ${workspaceFolder} 
▼  ▲  X  ↳ ${workspaceFolder}/include 
```
... compiles successfully but does not link as lacks some libraries.


## Compilet option `-contract`

It is said in the option list of the command `eosio-cpp`: 
> -contract=\<string\>       - Contract name

However, it is not said there that the setting has to be accompanied with corresponding adjustment in the definition of the contract:
> class [[eosio::contract(\<the same string\>)]]
